module.exports = {
	base_url : 'http://jira.cingular.net/',
	jira_api :{
		issues : {
			path:'jira/rest/api/2/issue/'
		},
		project :{
			path : 'jira/rest/api/2/project'		
		}
	}
}