'use strict';

/**
 * @namespace {AModule} App.Api.V2018.Abstracts.Module
 * @access public
 * @author Isaac Ewing
 * @version 1.0.0 - 07/24/18 02:21 pm - created
 */
class AModule {
    constructor() {
        //
    }
}

module.exports = AModule;